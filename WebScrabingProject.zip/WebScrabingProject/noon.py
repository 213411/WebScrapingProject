import requests
import tkinter as tk
from bs4 import BeautifulSoup
import time

def scrape_toys():
    url = "https://www.amazon.com/s?k=toys&ref=nav_bb_sb"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Safari/537.36"
    }

    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    product_list = soup.find_all("div", class_="s-result-item s-asin sg-col-0-of-12 sg-col-16-of-20 sg-col sg-col-12-of-16")
    for i, product in enumerate(product_list):
        name = product.find("span", class_="a-size-base-plus a-color-base a-text-normal")
        price = product.find("span", class_="a-offscreen")
        if name and price:
            product_name = name.get_text(strip=True)
            product_price = price.get_text(strip=True)
            listbox.insert(tk.END, f"Product: {product_name}   Price: {product_price}")
        
        # Add a time delay of 1 second between each iteration
        time.sleep(1)

# Create Tkinter window
window = tk.Tk()
window.title("Toy Prices")
window.geometry("400x400")

# Create Listbox to display the scraped data
listbox = tk.Listbox(window, width=50)
listbox.pack(pady=10)

# Scrape and display the data button
scrape_button = tk.Button(window, text="Scrape Toys", command=scrape_toys)
scrape_button.pack(pady=10)

# Run the Tkinter event loop
window.mainloop()
